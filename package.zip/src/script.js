// //Default. table view(no display). categorical view(display)
// document.getElementById("table").style.display = "none";
// document.getElementById("category").style.display = "block";

// //on table button click, displays table view
// document.getElementById("table_view").onclick = function () {
//   document.getElementById("table").style.display = "block";
//   document.getElementById("category").style.display = "none";
// };

// //on category button click, displays categorical view
// document.getElementById("category_view").onclick = function () {
//   document.getElementById("category").style.display = "block";
//   document.getElementById("table").style.display = "none";
// };
