module.exports = {
    mongoURI: "mongodb+srv://dbuser:dbuser@cluster0-phmwx.mongodb.net/test?retryWrites=true&w=majority",
    secretOrKey: "secret"
};
