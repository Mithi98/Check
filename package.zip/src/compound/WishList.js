import React, {Component} from 'react';

class WishList extends Component {
    render() {
        return (
            <div>


<h4>Hey</h4>



            </div>
        );
    }
}

export default WishList;
