import React from 'react';
import styled from 'styled-components';
import Slider from 'react-click';

const wrapper=styled.div
'width:100%';

const Page=styled.div



export default class SlideView extends React.Component {
    render(){
        return (
            <Wrapper>


            </Wrapper>
        )
    }
}


